-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: renca-brc
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `areas`
--

DROP TABLE IF EXISTS `areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `areas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `areas_id` int(11) DEFAULT NULL,
  `niveles_id` int(11) NOT NULL,
  `nueva` tinyint(1) NOT NULL DEFAULT '0',
  `concepto` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_areas_niveles1_idx` (`niveles_id`),
  KEY `fk_areas_areas1_idx` (`areas_id`),
  KEY `idx_areas_concepto` (`concepto`),
  KEY `idx_areas_nueva` (`nueva`),
  CONSTRAINT `fk_areas_areas1` FOREIGN KEY (`areas_id`) REFERENCES `areas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_areas_niveles1` FOREIGN KEY (`niveles_id`) REFERENCES `niveles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `coherencias`
--

DROP TABLE IF EXISTS `coherencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coherencias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `concepto` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_coherencia_concepto` (`concepto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `empleados`
--

DROP TABLE IF EXISTS `empleados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empleados` (
  `id` int(11) NOT NULL,
  `puestos_id` int(11) NOT NULL,
  `areas_id` int(11) NOT NULL,
  `sueldo_actual` decimal(10,2) NOT NULL,
  `titulo_actual` decimal(10,2) NOT NULL,
  `reencasillable` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`,`puestos_id`,`areas_id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_empleados_puestos1_idx` (`puestos_id`),
  KEY `fk_empleados_areas1_idx` (`areas_id`),
  CONSTRAINT `fk_empleados_areas1` FOREIGN KEY (`areas_id`) REFERENCES `areas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_empleados_personas1` FOREIGN KEY (`id`) REFERENCES `personas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_empleados_puestos1` FOREIGN KEY (`puestos_id`) REFERENCES `puestos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `empleados_puestos_sugeridos`
--

DROP TABLE IF EXISTS `empleados_puestos_sugeridos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empleados_puestos_sugeridos` (
  `puestos_id` int(11) NOT NULL,
  `empleados_id` int(11) NOT NULL,
  `default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`puestos_id`,`empleados_id`),
  KEY `fk_empleados_puestos_sugeridos_puestos1_idx` (`puestos_id`),
  KEY `fk_empleados_puestos_sugeridos_empleados1_idx` (`empleados_id`),
  CONSTRAINT `fk_empleados_puestos_sugeridos_empleados1` FOREIGN KEY (`empleados_id`) REFERENCES `empleados` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_empleados_puestos_sugeridos_puestos1` FOREIGN KEY (`puestos_id`) REFERENCES `puestos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `niveles`
--

DROP TABLE IF EXISTS `niveles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `niveles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `niveles_id` int(11) DEFAULT NULL,
  `concepto` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_niveles_niveles1_idx` (`niveles_id`),
  KEY `idx_niveles_concepto` (`concepto`),
  CONSTRAINT `fk_niveles_niveles1` FOREIGN KEY (`niveles_id`) REFERENCES `niveles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `personas`
--

DROP TABLE IF EXISTS `personas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `legajo` int(11) NOT NULL,
  `apellido` varchar(45) DEFAULT NULL,
  `nombres` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_personas` (`legajo`,`apellido`,`nombres`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `puesto_area_coherencia`
--

DROP TABLE IF EXISTS `puesto_area_coherencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `puesto_area_coherencia` (
  `puestos_id` int(11) NOT NULL,
  `areas_id` int(11) NOT NULL,
  `coherencias_id` int(11) NOT NULL,
  PRIMARY KEY (`puestos_id`,`areas_id`),
  KEY `fk_puesto_area_coherencia_coherencias1_idx` (`coherencias_id`),
  KEY `fk_puesto_area_coherencia_puestos1_idx` (`puestos_id`),
  KEY `fk_puesto_area_coherencia_areas1_idx` (`areas_id`),
  CONSTRAINT `fk_puesto_area_coherencia_areas1` FOREIGN KEY (`areas_id`) REFERENCES `areas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_puesto_area_coherencia_coherencias1` FOREIGN KEY (`coherencias_id`) REFERENCES `coherencias` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_puesto_area_coherencia_puestos1` FOREIGN KEY (`puestos_id`) REFERENCES `puestos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `puestos`
--

DROP TABLE IF EXISTS `puestos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `puestos` (
  `id` int(11) NOT NULL,
  `areas_id` int(11) DEFAULT NULL,
  `concepto` varchar(45) NOT NULL,
  `tipo_puesto` varchar(4) NOT NULL DEFAULT 'ANTE',
  PRIMARY KEY (`id`),
  KEY `fk_puestos_areas1_idx` (`areas_id`),
  KEY `IDX_puesto_concepto` (`concepto`),
  KEY `IDX_puesto_tipo` (`tipo_puesto`),
  CONSTRAINT `fk_puestos_areas1` FOREIGN KEY (`areas_id`) REFERENCES `areas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reencasillamiento_estados`
--

DROP TABLE IF EXISTS `reencasillamiento_estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reencasillamiento_estados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuarios_reencasilla_id` int(11) NOT NULL,
  `usuarios_niveles_reencasilla_id` int(11) NOT NULL,
  `usuarios_movimiento_id` int(11) NOT NULL,
  `usuarios_niveles_movimiento_id` int(11) NOT NULL,
  `rencasillamiento_empleados_id` int(11) NOT NULL,
  `rencasillamiento_puestos_actual_id` int(11) NOT NULL,
  `rencasillamiento_areas_actual_id` int(11) NOT NULL,
  `rencasillamiento_puestos_nuevo_id` int(11) NOT NULL,
  `rencasillamiento_areas_nueva_id` int(11) NOT NULL,
  `comentarios` text,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` varchar(15) DEFAULT NULL,
  `finalizado` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_reencasillamiento_estados_usuarios1_idx` (`usuarios_movimiento_id`,`usuarios_niveles_movimiento_id`),
  KEY `fk_reencasillamiento_estados_usuarios2_idx` (`usuarios_reencasilla_id`,`usuarios_niveles_reencasilla_id`),
  KEY `IDX_reenca_estado_finalizado` (`finalizado`),
  KEY `fk_reencasillamiento_estados_rencasillamiento1_idx` (`rencasillamiento_empleados_id`,`rencasillamiento_puestos_actual_id`,`rencasillamiento_areas_actual_id`,`rencasillamiento_puestos_nuevo_id`,`rencasillamiento_areas_nueva_id`),
  CONSTRAINT `fk_reencasillamiento_estados_rencasillamiento1` FOREIGN KEY (`rencasillamiento_empleados_id`, `rencasillamiento_puestos_actual_id`, `rencasillamiento_areas_actual_id`, `rencasillamiento_puestos_nuevo_id`, `rencasillamiento_areas_nueva_id`) REFERENCES `rencasillamientos` (`empleados_id`, `puestos_actual_id`, `areas_actual_id`, `puestos_nuevo_id`, `areas_nueva_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_reencasillamiento_estados_usuarios1` FOREIGN KEY (`usuarios_movimiento_id`, `usuarios_niveles_movimiento_id`) REFERENCES `usuarios` (`id`, `niveles_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_reencasillamiento_estados_usuarios2` FOREIGN KEY (`usuarios_reencasilla_id`, `usuarios_niveles_reencasilla_id`) REFERENCES `usuarios` (`id`, `niveles_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rencasillamientos`
--

DROP TABLE IF EXISTS `rencasillamientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rencasillamientos` (
  `empleados_id` int(11) NOT NULL,
  `puestos_actual_id` int(11) NOT NULL,
  `areas_actual_id` int(11) NOT NULL,
  `puestos_nuevo_id` int(11) NOT NULL,
  `areas_nueva_id` int(11) NOT NULL,
  `usuarios_aprueba_id` int(11) DEFAULT NULL,
  `usuarios_niveles_aprueba_id` int(11) DEFAULT NULL,
  `sueldo_nuevo` decimal(10,2) NOT NULL,
  `titulo_nuevo` decimal(10,2) NOT NULL,
  `rencasillado` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` timestamp NULL DEFAULT NULL,
  `ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`empleados_id`,`puestos_actual_id`,`areas_actual_id`,`puestos_nuevo_id`,`areas_nueva_id`),
  UNIQUE KEY `IDU_reenca_empleado` (`empleados_id`),
  KEY `fk_rencasillamiento_puestos1_idx` (`puestos_nuevo_id`),
  KEY `fk_rencasillamiento_areas1_idx` (`areas_nueva_id`),
  KEY `fk_rencasillamiento_usuarios1_idx` (`usuarios_aprueba_id`,`usuarios_niveles_aprueba_id`),
  KEY `fk_rencasillamiento_empleados1_idx` (`empleados_id`,`puestos_actual_id`,`areas_actual_id`),
  KEY `IDX_reenca_reencasillado` (`rencasillado`),
  CONSTRAINT `fk_rencasillamiento_areas1` FOREIGN KEY (`areas_nueva_id`) REFERENCES `areas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_rencasillamiento_empleados1` FOREIGN KEY (`empleados_id`, `puestos_actual_id`, `areas_actual_id`) REFERENCES `empleados` (`id`, `puestos_id`, `areas_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_rencasillamiento_puestos1` FOREIGN KEY (`puestos_nuevo_id`) REFERENCES `puestos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_rencasillamiento_usuarios1` FOREIGN KEY (`usuarios_aprueba_id`, `usuarios_niveles_aprueba_id`) REFERENCES `usuarios` (`id`, `niveles_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `niveles_id` int(11) NOT NULL,
  `user_name` varchar(45) NOT NULL,
  `user_pass` varchar(45) NOT NULL,
  `user_created` varchar(45) NOT NULL,
  `user_modified` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` timestamp NULL DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`,`niveles_id`),
  UNIQUE KEY `idu_usuarios_user` (`id`),
  UNIQUE KEY `user_name_UNIQUE` (`user_name`),
  KEY `fk_usuarios_niveles1_idx` (`niveles_id`),
  CONSTRAINT `fk_usuarios_niveles1` FOREIGN KEY (`niveles_id`) REFERENCES `niveles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_usuarios_personas` FOREIGN KEY (`id`) REFERENCES `personas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usuarios_areas`
--

DROP TABLE IF EXISTS `usuarios_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios_areas` (
  `usuarios_id` int(11) NOT NULL,
  `usuarios_niveles_id` int(11) NOT NULL,
  `areas_id` int(11) NOT NULL,
  KEY `fk_usuarios_areas_usuarios1_idx` (`usuarios_id`,`usuarios_niveles_id`),
  KEY `fk_usuarios_areas_areas1_idx` (`areas_id`),
  CONSTRAINT `fk_usuarios_areas_areas1` FOREIGN KEY (`areas_id`) REFERENCES `areas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_usuarios_areas_usuarios1` FOREIGN KEY (`usuarios_id`, `usuarios_niveles_id`) REFERENCES `usuarios` (`id`, `niveles_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-13 19:21:49
