--- CONSULTAS SQL REALIZADAS VARIAS - PROYECTO RENCA

select distinct SECRETARIA_N1 AS area, 1 as 'niveles_id'
from renca -- 15
union
select distinct SUBSECRETARIA_N2 AS area
from renca  -- 26
union
select distinct DIRECCION_GENERAL_N3 AS area
from renca -- 41
union
select distinct DIRECCION_N4 AS area
from renca -- 82
union
select distinct DEPARTAMENTO_N5 AS area
from renca -- 170
union
select distinct DIVISION_N6 AS area
from renca -- 238
union
select distinct SECCION_N7 AS area
from renca -- 300

ORDER BY area asc


select distinct CONTROL_GESTION_N0 AS area, 0 as 'niveles_id'
from renca

select * from renca where direccion_n4 = 'SISTEMAS'

select id  FROM AREAS WHERE niveles_id = 0

select distinct area from renca


select * from (
-- --------nivel 1  15 row


 select k.*, c.id as id_area_depende_de,c.id as areas_id from 
 (
 select distinct a.niveles_id , a.id as id_area,a.concepto, b.control_gestion_n0 as depende_de
from areas_tmp a
inner join renca b on b.secretaria_n1=a.concepto
 where 
 a.niveles_id = 1 -- nivel 1
 )k inner join areas_tmp c on k.depende_de=c.concepto  
 where 
 c.niveles_id = 0
 
 union 
 -- -----nivel 2 11 row
 
 select k.*, c.id as id_area_depende_de,c.id as areas_id from 
 (
 select distinct a.niveles_id , a.id as id_area,a.concepto, b.SECRETARIA_N1 as depende_de
from areas_tmp a
inner join renca b on b.SUBSECRETARIA_N2=a.concepto
 where 
 a.niveles_id = 2 -- nivel 2
 )k inner join areas_tmp c on k.depende_de=c.concepto  
 where 
 c.niveles_id = 1
 
 union
 
  -- -----nivel 3 4 row
 select k.*, c.id as id_area_depende_de,c.id as areas_id from 
 (
 select distinct a.niveles_id , a.id as id_area,a.concepto, b.SUBSECRETARIA_N2 as depende_de
from areas_tmp a
inner join renca b on b.DIRECCION_GENERAL_N3=a.concepto
 where 
 a.niveles_id = 3 -- nivel 3
 )k inner join areas_tmp c on k.depende_de=c.concepto  
 where 
 c.niveles_id = 2
 
 
 union
 
  -- -----nivel 4 23 row
 select k.*, c.id as id_area_depende_de,c.id as areas_id from 
 (
 select distinct a.niveles_id , a.id as id_area,a.concepto, b.DIRECCION_GENERAL_N3 as depende_de
from areas_tmp a
inner join renca b on b.DIRECCION_N4=a.concepto
 where 
 a.niveles_id = 4 -- nivel 3
 )k inner join areas_tmp c on k.depende_de=c.concepto  
 where 
 c.niveles_id = 3
 
 union
 
 -- --nivel 5 58 row
 select k.*, c.id as id_area_depende_de,c.id as areas_id from 
 (
 select distinct a.niveles_id , a.id as id_area,a.concepto, b.DIRECCION_N4 as depende_de
from areas_tmp a
inner join renca b on b.DEPARTAMENTO_N5=a.concepto
 where 
 a.niveles_id = 5 -- nivel 3
 )k inner join areas_tmp c on k.depende_de=c.concepto  
 where 
 c.niveles_id = 4
 
 union
 
 -- --nivel 6 27 row
 select k.*, c.id as id_area_depende_de,c.id as areas_id from 
 (
 select distinct a.niveles_id , a.id as id_area,a.concepto, b.DEPARTAMENTO_N5 as depende_de
from areas_tmp a
inner join renca b on b.DIVISION_N6=a.concepto
 where 
 a.niveles_id = 6 -- nivel 3
 )k inner join areas_tmp c on k.depende_de=c.concepto  
 where 
 c.niveles_id = 5
 
 union
 
  -- --nivel 7 18 row
 select k.*, c.id as id_area_depende_de,c.id as areas_id from 
 (
 select distinct a.niveles_id , a.id as id_area,a.concepto, b.DIVISION_N6 as depende_de
from areas_tmp a
inner join renca b on b.SECCION_N7=a.concepto
 where 
 a.niveles_id = 7 -- nivel 3
 )k inner join areas_tmp c on k.depende_de=c.concepto  
 where 
 c.niveles_id = 6
  ) k where k.concepto = 'SISTEMAS'
 

 
-------------------------------- ##############  ANALISIS DE DATOS EN ARQUITECTURA ARBOL ############## 
  
 
truncate table areas
 SET FOREIGN_KEY_CHECKS=0;

 -- Busco un area y dependencia
 select * from areas_arbol_tmp where concepto = 'SISTEMAS'


 -- Busco quien depende de mi dependencia
 SELECT * FROM areas_arbol_tmp where depende_de = 'SISTEMAS'
 
 -- Busco un area SISTEMAS,  y devuelvo el nivel junto con sus nodos 
SELECT * 
FROM areas_arbol_tmp a
INNER JOIN areas_arbol_tmp b ON (a.id_area = b.areas_id)
where a.concepto = 'SISTEMAS'


-- ############## Vista de depenedencias de area y arbol de la misma ############## 
-- Busco area y todas sus dependencias en tabla real
SELECT 
a.id as id_area,
a.concepto as area,
c.concepto,
a.niveles_id as nivel_area,
e.concepto as depende_de,
a.areas_id as areas_id_depende_de,
e.niveles_id as depende_de_nivel, 
b.concepto as tiene_a_cargo,
b.id as id_area_a_cargo,
d.concepto as tiene_a_cargo_concepto
FROM areas a
INNER JOIN areas b ON (a.id = b.areas_id)
INNER JOIN niveles c ON (a.niveles_id = c.id)
INNER JOIN niveles d ON (d.id = b.niveles_id)
INNER JOIN areas e ON (a.areas_id = e.id)
-- where a.concepto = 'SISTEMAS'
 where a.concepto = 'OBRAS Y SERVICIOS PUBLICOS' -- error econtrado en area nro. 32
-- ############## FIN Vista de depenedencias de area y arbol de la misma


-- ############## Armo proceso para las siguientes areas que se repiten , ejemplo legajo 618 622
 select id_area as id, areas_id,niveles_id,'0' as nueva,concepto
 from areas_arbol_tmp where id_area in (  
select distinct id_area from (
 select id_area, count(id_area)as cantidad 
 from areas_arbol_tmp 
 group by id_area 
 having   cantidad  > 1 
 order by cantidad desc
 ) k
) order by id

--

 select id_area as id, areas_id,niveles_id,'0' as nueva,concepto
 from areas_arbol_tmp where id_area in (  
select distinct id_area from (
 select id_area, count(id_area)as cantidad 
 from areas_arbol_tmp 
 group by id_area 
 having   cantidad  > 1 
 order by cantidad desc
 ) k
) order by id
-- ############## FIN Aramo proceso para las siguientes areas que se repiten  ############## 


-- ############## EN QUE AREA TRABAJA CADA EMPLEADO  ############## 
-- 30 + 2072 = 2102(select count(*) from renca)
select * from renca where legajo not in (

	select legajo from (
	-- todos los que trabajan la secretaria_n1
	select a.*from 
	 (select 
	 id_legajo,legajo,secretaria_n1,subsecretaria_n2,direccion_general_n3,direccion_n4,departamento_n5,division_n6,seccion_n7
	 from renca)a
	 inner join
	 (select 
	 id_legajo,legajo,seccion_n7
	 from renca)b
	 on (a.legajo=b.legajo) 
	 and  (a.secretaria_n1=b.seccion_n7)
	 and  (a.subsecretaria_n2=b.seccion_n7)
	 and  (a.direccion_general_n3=b.seccion_n7)
	 and  (a.direccion_n4=b.seccion_n7)
	 and  (a.departamento_n5=b.seccion_n7)
	 and  (a.division_n6=b.seccion_n7)
	 and  (a.seccion_n7=b.seccion_n7)
	 union
	 -- todos los que trabajan la subsecretaria_n2
	select a.* from 
	 (select 
	 id_legajo,legajo,secretaria_n1,subsecretaria_n2,direccion_general_n3,direccion_n4,departamento_n5,division_n6,seccion_n7
	 from renca)a
	 inner join
	 (select 
	 id_legajo,legajo,seccion_n7
	 from renca)b
	 on (a.legajo=b.legajo) 
	 and  (a.secretaria_n1<>b.seccion_n7)
	 and  (a.subsecretaria_n2=b.seccion_n7)
	 and  (a.direccion_general_n3=b.seccion_n7)
	 and  (a.direccion_n4=b.seccion_n7)
	 and  (a.departamento_n5=b.seccion_n7)
	 and  (a.division_n6=b.seccion_n7)
	 and  (a.seccion_n7=b.seccion_n7)
	 union
	 -- todos los que trabajan la direccion_general_n3
	select a.* from 
	 (select 
	 id_legajo,legajo,secretaria_n1,subsecretaria_n2,direccion_general_n3,direccion_n4,departamento_n5,division_n6,seccion_n7
	 from renca)a
	 inner join
	 (select 
	 id_legajo,legajo,seccion_n7
	 from renca)b
	 on (a.legajo=b.legajo) 
	 and  (a.secretaria_n1<>b.seccion_n7)
	 and  (a.subsecretaria_n2<>b.seccion_n7)
	 and  (a.direccion_general_n3=b.seccion_n7)
	 and  (a.direccion_n4=b.seccion_n7)
	 and  (a.departamento_n5=b.seccion_n7)
	 and  (a.division_n6=b.seccion_n7)
	 and  (a.seccion_n7=b.seccion_n7)
	 -- todos los que trabajan la direccion_n4
	 union
	select a.* from 
	 (select 
	 id_legajo,legajo,secretaria_n1,subsecretaria_n2,direccion_general_n3,direccion_n4,departamento_n5,division_n6,seccion_n7
	 from renca)a
	 inner join
	 (select 
	 id_legajo,legajo,seccion_n7
	 from renca)b
	 on (a.legajo=b.legajo) 
	 and  (a.secretaria_n1<>b.seccion_n7)
	 and  (a.subsecretaria_n2<>b.seccion_n7)
	 and  (a.direccion_general_n3<>b.seccion_n7)
	 and  (a.direccion_n4=b.seccion_n7)
	 and  (a.departamento_n5=b.seccion_n7)
	 and  (a.division_n6=b.seccion_n7)
	 and  (a.seccion_n7=b.seccion_n7)
	 -- todos los que trabajan la departamento_n5
	 union
	select a.* from 
	 (select 
	 id_legajo,legajo,secretaria_n1,subsecretaria_n2,direccion_general_n3,direccion_n4,departamento_n5,division_n6,seccion_n7
	 from renca)a
	 inner join
	 (select 
	 id_legajo,legajo,seccion_n7
	 from renca)b
	 on (a.legajo=b.legajo) 
	 and  (a.secretaria_n1<>b.seccion_n7)
	 and  (a.subsecretaria_n2<>b.seccion_n7)
	 and  (a.direccion_general_n3<>b.seccion_n7)
	 and  (a.direccion_n4<>b.seccion_n7)
	 and  (a.departamento_n5=b.seccion_n7)
	 and  (a.division_n6=b.seccion_n7)
	 and  (a.seccion_n7=b.seccion_n7)
	 -- todos los que trabajan la division_n6
	 union
	select a.* from 
	 (select 
	 id_legajo,legajo,secretaria_n1,subsecretaria_n2,direccion_general_n3,direccion_n4,departamento_n5,division_n6,seccion_n7
	 from renca)a
	 inner join
	 (select 
	 id_legajo,legajo,seccion_n7
	 from renca)b
	 on (a.legajo=b.legajo) 
	 and  (a.secretaria_n1<>b.seccion_n7)
	 and  (a.subsecretaria_n2<>b.seccion_n7)
	 and  (a.direccion_general_n3<>b.seccion_n7)
	 and  (a.direccion_n4<>b.seccion_n7)
	 and  (a.departamento_n5<>b.seccion_n7)
	 and  (a.division_n6=b.seccion_n7)
	 and  (a.seccion_n7=b.seccion_n7)
	 -- todos los que trabajan la seccion_n7
	 union
	select a.* from 
	 (select 
	 id_legajo,legajo,secretaria_n1,subsecretaria_n2,direccion_general_n3,direccion_n4,departamento_n5,division_n6,seccion_n7
	 from renca)a
	 inner join
	 (select 
	 id_legajo,legajo,seccion_n7
	 from renca)b
	 on (a.legajo=b.legajo) 
	 and  (a.secretaria_n1<>b.seccion_n7)
	 and  (a.subsecretaria_n2<>b.seccion_n7)
	 and  (a.direccion_general_n3<>b.seccion_n7)
	 and  (a.direccion_n4<>b.seccion_n7)
	 and  (a.departamento_n5<>b.seccion_n7)
	 and  (a.division_n6<>b.seccion_n7)
	 and  (a.seccion_n7=b.seccion_n7)
	 ) k
)
 

15:47:43	select * from   (select   id_legajo,legajo,secretaria_n1  from renca)a  inner join  (select   id_legajo,legajo,seccion_n7  from renca)b  on (a.legajo=b.legajo)   and  (a.secretaria_n1=b.seccion_n7)  and  (a.subsecretaria_n2=b.seccion_n7)	Error Code: 1054. Unknown column 'a.subsecretaria_n2' in 'on clause'	0.00031 sec

 select subsecretaria_n2 from renca
 where secretaria_n1 in (select seccion_n7 from renca)
 order by seccion_n7
 
-- ############## FIN EN QUE AREA TRABAJA CADA EMPLEADO  ############## 

-- ############## CANTIDAD DE AREAS
select distinct seccion_n7 from renca -- 300
-- ############## CANTIDAD DE AREAS


-- MODELO DE DATOS DER
-- ESTRUCUTURA DE MODELO DE DATOS SQL
-- CANTIDDA DE PROCESOS ETL : 31
-- CANTIDAD DE SUBPROCES/OBJETOS ETL 28
-- ARCHIVOS XLS MSCB
